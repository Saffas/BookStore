﻿using BookStore.Base;
using BookStore.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BookStore.Page
{
    /// <summary>
    /// Логика взаимодействия для CartShop.xaml
    /// </summary>
    public partial class CartShop : Window
    {
        Order order;
        List<OrderProduct> orderProducts;

        decimal totalPriceAmount;
        decimal totalDiscountAmount;

        public CartShop(List<Product> products)
        {
            InitializeComponent();

            order = new Order();
            order.id = AppData.db.Order.Max(o => o.id) + 1;
            orderProducts = new List<OrderProduct>();
            PickUpPointBox.ItemsSource = AppData.db.PickUpPoint.ToList();


            foreach (var product in products) 
            {
                var existingOrderProduct = orderProducts.FirstOrDefault(p => p.idProduct ==  product.id);
                if (existingOrderProduct != null)
                {
                    existingOrderProduct.QuantityProductOrder++;
                }
                else
                {
                    var ordersProduct = new OrderProduct()
                    {
                        idOrder = order.id,
                        Product = product,
                        idProduct = product.id,
                        QuantityProductOrder = 1
                    };
                    orderProducts.Add(ordersProduct);
                }
            }
            ListOrder.ItemsSource = orderProducts;
            CalcusShowPriceProduct(orderProducts);
        }

        private void CalcusShowPriceProduct( List<OrderProduct> productList)
        {
            totalDiscountAmount = 0;
            totalPriceAmount = 0;

            foreach (var product in productList)
            {
                decimal productPriceAmount = product.Product.Price * product.QuantityProductOrder;
                totalPriceAmount += productPriceAmount;
                if (product.Product.Discount != null)
                {
                    decimal productDiscountAmount = (decimal)((productPriceAmount / 100) * product.Product.Discount);
                    totalDiscountAmount += productDiscountAmount;
                    totalPriceAmount -= productDiscountAmount;
                }
            }

            TotalPriceProductTB.Text = $"{totalPriceAmount.ToString()}";
            TotalDiscountProductTB.Text = $"{totalDiscountAmount.ToString()}";
        }

        private void DeleteProductToBtn_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button).DataContext is OrderProduct orderInProduct)
            {
                    orderProducts.Remove(orderProducts.Where(x => x.idProduct == orderInProduct.idProduct).FirstOrDefault());

            }
            CalcusShowPriceProduct(orderProducts);
            ListOrder.ItemsSource = orderProducts;
            ListOrder.Items.Refresh();
        }

        private void BsckMenu_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void PlusToProduct_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button).DataContext is OrderProduct orderInProduct)
            {
                var ordersProduct = orderProducts.Find(x => x.idProduct == orderInProduct.idProduct);
                if (ordersProduct != null)
                {
                    ordersProduct.QuantityProductOrder++;
                }
            }
                CalcusShowPriceProduct(orderProducts);
                ListOrder.ItemsSource = orderProducts;
                ListOrder.Items.Refresh();
               
        }

        private void MinusToProduct_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as Button).DataContext is OrderProduct orderInProduct)
            {
               orderProducts.Where(x => x.idProduct == orderInProduct.idProduct).FirstOrDefault().QuantityProductOrder--;

                if (orderProducts.Where(x => x.idProduct == orderInProduct.idProduct).FirstOrDefault().QuantityProductOrder == 0)
                {
                    orderProducts.Remove(orderProducts.Where(x => x.idProduct == orderInProduct.idProduct).FirstOrDefault());
                }
            }

            CalcusShowPriceProduct(orderProducts);
            ListOrder.ItemsSource = orderProducts;
            ListOrder.Items.Refresh();
        }

        private void FormOrder_Click(object sender, RoutedEventArgs e)
        {
            if (PickUpPointBox.SelectedItem != null)
            {
                var maxOrderCode = AppData.db.Order.Max(o => o.CodeDelivery);
                var newOrder = new Order
                {
                    DateDelivery = DeliveryDate(orderProducts),
                    idPickUpPoint = ((PickUpPoint)PickUpPointBox.SelectedItem).id,
                    idStatus = 0,
                    CodeDelivery = maxOrderCode++,
                };
                AppData.db.Order.Add(newOrder);
                foreach (var item in orderProducts)
                {
                    var newOrderProduct = new OrderProduct()
                    {
                        idOrder = newOrder.id,
                        idProduct = item.idProduct,
                        QuantityProductOrder = item.QuantityProductOrder,
                    };
                    AppData.db.SaveChanges();
                }
            }
            else
            {
                MessageBox.Show("Выберите пункт выдачи.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private DateTime DeliveryDate(List<OrderProduct> oProductList)
        {
            if (oProductList.Count >= 6)
            {
                return DateTime.Now.AddDays(6);
            }
            else
            {
                foreach (var item in oProductList)
                {
                    if (item.Product.Quantity < item.QuantityProductOrder)
                    {
                        return DateTime.Now.AddDays(6);
                    }
                }
            }
            return DateTime.Now.AddDays(3);

        }
    }
}
