﻿using BookStore.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Classes
{
    public static class AppData
    {
        public static user9Entities db = new user9Entities();
    }
}
