﻿using BookStore.Base;
using BookStore.Classes;
using BookStore.Page;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BookStore
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Product> products;
        public MainWindow()
        {
            InitializeComponent();
            ListProduct.ItemsSource = AppData.db.Product.ToList();
        }

        private void AddProductToBtn_Click(object sender, RoutedEventArgs e)
        {
            if (products == null)
            {
                products = new List<Product>();
            }
            Product selectedProduct = (Product)ListProduct.SelectedItem;
            if (selectedProduct != null)
            {
                products.Add(selectedProduct);
                MessageBox.Show("Товар " + $"{Name}" + " добавлен в заказ");
                CartShopping.IsEnabled = true;
            }
            else
            {
                MessageBox.Show("Товар не выбран");
            }

        }

        private void OpenCart_Click(object sender, RoutedEventArgs e)
        {
            CartShop cartShop = new CartShop(products);
            cartShop.ShowDialog();
        }

        private void AddProductToMenu_Click(object sender, RoutedEventArgs e)
        {
            if (products == null)
            {
                products = new List<Product>();
            }
            if((sender as MenuItem).DataContext is Product product)
            {
                products.Add(product);
            }

            MessageBox.Show("Товар " + $"{Name}" + " добавлен в заказ");
            CartShopping.IsEnabled = true;
        }
    }
}
